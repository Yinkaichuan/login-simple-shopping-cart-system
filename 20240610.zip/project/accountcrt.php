<?php
$servername = "localhost";
$dbusername = "root"; // 數據庫用戶名
$dbpassword = ""; // 數據庫密碼
$dbname = "people"; // 數據庫名稱

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// 檢查連接
if ($conn->connect_error) {
    die("連接失敗: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // 防止 SQL 注入
    $username = $conn->real_escape_string($username);

    // 從數據庫中檢索用戶
    $sql = "SELECT * FROM userdata WHERE username='$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        
        // 驗證密碼
        if ($password === $row['password']) {
            // 登錄成功後重定向到 shop.html
            header('Location: shop.html');
            exit();
        } else {
            echo "無效的用戶名或密碼。";
        }
    } else {
        echo "無效的用戶名或密碼。";
    }
}

// 關閉連接
$conn->close();
?>
